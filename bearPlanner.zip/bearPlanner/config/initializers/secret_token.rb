# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
BearPlanner::Application.config.secret_token = 'c82e45ae7f1d7dd8a2c8ab78f137b3f73fb55b5ceb7f379489e147a8cf09196d11835ee90dd51fd9a7b45bec4672c023c2b20e3c3f08644063cd5c5879c0bc15'
