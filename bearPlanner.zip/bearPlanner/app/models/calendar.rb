class Calendar < ActiveRecord::Base
end
