class Invite < ActiveRecord::Base
end
