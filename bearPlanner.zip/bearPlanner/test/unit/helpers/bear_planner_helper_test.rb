require 'test_helper'

class BearPlannerHelperTest < ActionView::TestCase
end
